
var osmosis = require('osmosis');
var Redis = require('ioredis');
var redis = new Redis(6379, '47.92.132.103')        // 192.168.1.1:6379

var mysql = require('mysql');
var connection = mysql.createConnection({
    host: '47.92.132.103',
    user: 'leven',
    password: '56os.com',
    database: 'ic'
});
connection.connect();
var searchUrl = 'http://www.electronics-ic.com/product/a/';
function start() {
    "use strict";

    redis.rpop('ic:index', function (err, index) {
        open_page(index)
    })
}


function open_page(index) {

    var url = searchUrl + index + ".html";

    console.log("Opening " + url);


    const t = osmosis.get(url)
        .set({
            title: 'title',
            keywords: 'meta[4]@content',
            description: "meta[5]@content"
        }).find('.product-info').set({
            'name': 'h1',
            'image': '.cover img@src',

            'brandLogo': '.mfg-cover@src'

        }).find(".product-info .info")
        .set({

            'desc': '.description',
            'brand_link': '.brand a@href',
            'brand': '.brand a',
            'partStatus': '.partStatus',
            'pdf': osmosis.find('.datasheet//a').set('href', '@href'),

        }).find('#main').then(function (context, data, next, done) {

            var items = context.find('.specifications tr')
            // //var items=spec.find('tr')
            //
            //  console.log(items.length())
            //
            var specifications = {}
            items.forEach(function (item, n) {
                // console.log(item.find('th')[0].text())

                specifications[item.find('th')[0].text()] = item.find('td')[0].text()


            })

            //parse(data)
            data.specifications = specifications
            next(context, data)
            //done()
        })
        .data(function (data) {
            data.oid = index
            data.url = url
            //console.log(data)
            parse(data)


        })
        .error(console.log)
        .debug(console.log)
        /**** Same as above ****/
        .done(function () {

            start();
        })
}

function parse(data) {
    "use strict";
    console.log(data)
    data.pdf = JSON.stringify(data.pdf)
    data.specifications = JSON.stringify(data.specifications)

    var query = connection.query('INSERT INTO stock SET ?', data, function (err, result) {
        // Neat!
        if (err) {
            console.log(err)
        }
        start();
        console.log(result)
    });
    // redis.set("product:" + data.index, data);
}


start()