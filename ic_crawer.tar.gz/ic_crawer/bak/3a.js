/**
 * Created by leven on 17/4/29.
 */

var ssdb = require('ssdb');
var co = require('co');
var osmosis = require('osmosis');

var searchUrl = 'http://www.3acomponents.com/products/details/';

var key = '3a_index';

var pool = ssdb.createPool({
    host: 'game.pmker.com',
    port: 8888,
    auth: undefined,  // ssdb server auth password
    authCallback: function(err, data) {if (err) throw err;},  // callback function on auth
    size: 1,  // connection pool size
    timeout: 0,
    promisify: true

});

var conn = pool.acquire();


var mysql      = require('mysql');
var connection = mysql.createConnection({
    host     : 'game.pmker.com',
    user     : 'leven',
    password : '56os.com',
    database : 'ic'
});
connection.connect();
// connection.query('SELECT 1 + 1 AS solution', function(err, rows, fields) {
//     if (err) throw err;
//     console.log('The solution is: ', rows[0].solution);
// });

co(function *(){

    function open_page(index) {

      var  url=searchUrl+index;
        /**** Same as above ****/
        console.log("Opening " + url);


        const t = osmosis.get(url).find(".preview img@src")
            .set('cover')

            .find(".prod-info")
            .set({
                'name':'h2',
                'desc':'p[0]',
                'brand_link':'p[1]',
                'brand':'.brand a@text',
                'partStatus':'.partStatus',


            })
            .find('.pdf')
            .then(function (context,data,next) {
                var items = context.find('a@href');
                var pdf=[]
                items.forEach(function(item,n) {
                    pdf.push(item)
                   // data[item.find('th')[0].text()]=item.find('td')[0].text()



                })
                data.pdf=JSON.stringify(pdf)

                next(items, data);
            })
            .find(".specifications")


            .then(function(context, data, next) {
                var items = context.find('tr');

                items.forEach(function(item,n) {

                    data[item.find('th')[0].text()]=item.find('td')[0].text()



                })

                next(items, data);
            })



            .data(function(data) {
                data.idd=index
                data.url=url
                console.log(data)
                  parse(data)

                // var json=data;
                // json.desc=(data.desc+"").toString().replace("Desc : ","")
                //json.url=url
                // console.log(json);

            })
            .error(console.log)
            .debug(console.log)
            /**** Same as above ****/
            .done(function() {
                index++;
                 conn.set(key,index);
                 //open_page(index);
            })
    }

    function  parse(data){
        "use strict";
        console.log(data)


        var query = connection.query('INSERT INTO product SET ?', data, function(err, result) {
            // Neat!
            if(err){
                console.log(err)
            }
            console.log(result)
        });
          conn.set("product:"+data.index,data);
    }


    var index = yield conn.get(key);

    if(!index){
        yield conn.set(key,1);
        index=1

    }
    console.log(index)
    index=1613
    open_page(index)

}).catch(function(err) {
    console.error(err)
});
