/**
 * Created by leven on 17/4/29.
 */
//6215054

var Redis = require('ioredis');
var redis = new Redis();


//var pipeline = redis.pipeline();

for(var i=1;i<6215054;i++){
    redis.lpush("icc:index",i)
}

// pipeline.exec(function (err, results) {
//     contosle.log( results);
//     // `err` is always null, and `results` is an array of responses
//     // corresponding to the sequence of queued commands.
//     // Each response follows the format `[err, result]`.
// });
