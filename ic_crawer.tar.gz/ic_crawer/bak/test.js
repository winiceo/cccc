/**
 * Created by leven on 17/4/29.
 */
//6215054

var co = require('co');
var osmosis = require('osmosis');
var Redis = require('ioredis');
var redis = new Redis();
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'game.pmker.com',
    user: 'leven',
    password: '56os.com',
    database: 'ic'
});
connection.connect();
var searchUrl = 'http://www.electronics-ic.com/product/a/';
function start() {
    "use strict";
    redis.rpop('ic:index', function (err, index) {
        open_page(index)
    })
}


function open_page(index) {

    var url = searchUrl + index + ".html";

    console.log("Opening " + url);


    const t = osmosis.get(url)

        .find(".specifications")
        .then(function (context, data, next) {
            var items=context.find('tr')
            //var items = oo.find('tr');
            var specifications = {}
            items.forEach(function (item, n) {

                specifications[item.find('th')[0].text()] = item.find('td')[0].text()


            })
            data.specifications = specifications

            next(items, data);
        })


        .data(function (data) {
            data.oid = index
            data.url = url
            console.log(data)
            parse(data)


        })
        .error(console.log)
        .debug(console.log)
        /**** Same as above ****/
        .done(function () {

            start();
        })
}

function parse(data) {
    "use strict";
    console.log(data)
    data.pdf = JSON.stringify(data.pdf)
    data.specifications = JSON.stringify(data.specifications)

    var query = connection.query('INSERT INTO product SET ?', data, function (err, result) {
        // Neat!
        if (err) {
            console.log(err)
        }
        console.log(result)
    });
    redis.set("product:" + data.index, data);
}




start()