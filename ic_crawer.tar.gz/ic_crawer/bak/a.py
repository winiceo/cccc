#!/usr/bin/python
for i in range(6215054):
    print 'lpush ic:index',str(i)