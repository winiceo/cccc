var osmosis = require('osmosis');

var co = require('co');

var pool = ssdb.createPool({promisify: true});
var conn = pool.acquire();

co(function *(){
    var key = 'index';

    var index = yield conn.get(key);
    open_page();
    console.log(a, b);  // 1 'val'
}).catch(function(err) {
    console.error(err)
});


var searchUrl = 'http://www.electronics-ic.com/product/a/';

var Redis = require('ioredis');
var redis = new Redis();
var index=0

redis.get('index', function (err, result) {
   index=result||1;

    open_page();
});
function open_page() {
    url=searchUrl+index+".html";
    /**** Same as above ****/
    console.log("Opening " + url);


    osmosis.get(url).find(".product-info")
        .set({
            'cover': '.cover a@href',
            'title':   'h1'

        })
        .find(".info")
        .set({
            'name':'h2',
            'desc':'.description',
            'brand_link':'.brand a@href',
            'brand':'.brand a@text',
            'partStatus':'.partStatus',
            'pdf':".pdf@href",

        })
        .find(".specifications")


        .then(function(context, data, next) {
            var items = context.find('tr');
            var json={}
            items.forEach(function(item,n) {
                // let td={
                //     "a1":item.find('th')[0].text(),
                //     "a2":item.find('td')[0].text(),
                // }
                json[item.find('th')[0].text()]=item.find('td')[0].text()

                //  console.log(item.text())
                // console.log(json)


            })
            data.specifications=json
            next(items, data);
        })



        .data(function(data) {
            console.log(data)

            // var json=data;
            // json.desc=(data.desc+"").toString().replace("Desc : ","")
            //json.url=url
            // console.log(json);

        })
        .error(console.log)
        .debug(console.log)
        /**** Same as above ****/
        .done(function() {
            index++;
            redis.set('index',index)
            open_page();
        })
}


//
// var url = 'https://www.magentocommerce.com/magento-connect/customer-experience/alternative-sales-models.html';
//
// osmosis.get(url)
//     .find('title')
//     .set('title')
//     .find('#category-extension-list li.item')
//     .set({
//         extensions: [
//             {
//                 'name': 'h2.featured-extension-title',
//                 'link': 'h2.featured-extension-title a@href',
//             }
//         ]
//     })
//     .data(function(document) {
//         console.log(document);
//         console.log("====");
//     })
// ;